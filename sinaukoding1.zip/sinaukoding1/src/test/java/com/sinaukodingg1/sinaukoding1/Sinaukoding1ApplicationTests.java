package com.sinaukodingg1.sinaukoding1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sinaukoding1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
